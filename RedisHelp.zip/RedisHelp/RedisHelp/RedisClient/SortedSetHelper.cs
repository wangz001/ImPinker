﻿using IRedisClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RedisClient
{
   public class SortedSetHelper: SortSetStore
    {
       public SortedSetHelper(string guid)
        {
            prxoy = RedisClientManger.GetPrxoy(guid);
            hpcom = prxoy.hpcom;
        }
        DBConnectProxy prxoy = null;
        HelpCom hpcom = null;

        public HelpCom Hpcom
        {
            get
            {
                return hpcom;
            }

            set
            {
                hpcom = value;
            }
        }
        #region SortedSet 有序集合

        #region 同步方法

        /// <summary>
        /// 添加
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        /// <param name="score"></param>
        public override bool SortedSetAdd<T>(string key, T value, double score)
        {
            key = hpcom.AddSysCustomKey(key);
            return hpcom.Do(redis => redis.SortedSetAdd(key, hpcom.ConvertJson<T>(value), score));
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public override bool SortedSetRemove<T>(string key, T value)
        {
            key = hpcom.AddSysCustomKey(key);
            return hpcom.Do(redis => redis.SortedSetRemove(key, hpcom.ConvertJson(value)));
        }

        /// <summary>
        /// 获取全部
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public override List<T> SortedSetRangeByRank<T>(string key)
        {
            key = hpcom.AddSysCustomKey(key);
            return hpcom.Do(redis =>
            {
                var values = redis.SortedSetRangeByRank(key);
                return hpcom.ConvetList<T>(values);
            });
        }

        /// <summary>
        /// 获取集合中的数量
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public override long SortedSetLength(string key)
        {
            key = hpcom.AddSysCustomKey(key);
            return hpcom.Do(redis => redis.SortedSetLength(key));
        }
        public override bool SortedSetAddItem<T>(string key, T value, double score)
        {
            key = hpcom.AddSysCustomKey(key);
            return hpcom.Do(redis => redis.SortedSetAdd(key, hpcom.Serializer<T>(value), score));
        }

        public override bool SortedSetRemoveItem<T>(string key, T value)
        {
            key = hpcom.AddSysCustomKey(key);
            return hpcom.Do(redis => redis.SortedSetRemove(key, hpcom.Serializer(value)));
        }

        public override List<T> SortedSetRangeByRankItem<T>(string key)
        {
            key = hpcom.AddSysCustomKey(key);
            return hpcom.Do(redis =>
            {
                var values = redis.SortedSetRangeByRank(key);
                return hpcom.ConvetListItem<T>(values);
            });
        }
        #endregion 同步方法

        #region 异步方法
        public override Task<bool> SortedSetAddAsync<T>(string key, T value, double score)
        {
            key = hpcom.AddSysCustomKey(key);
            return  hpcom.DoAsy(redis => redis.SortedSetAddAsync(key, hpcom.ConvertJson<T>(value), score)).Result;
        }

        public override Task<bool> SortedSetRemoveAsync<T>(string key, T value)
        {
            key = hpcom.AddSysCustomKey(key);
            return  hpcom.DoAsy(redis => redis.SortedSetRemoveAsync(key, hpcom.ConvertJson(value))).Result;
        }

        public override Task<List<T>> SortedSetRangeByRankAsync<T>(string key)
        {
            key = hpcom.AddSysCustomKey(key);
            var r =  hpcom.DoAsy(redis => redis.SortedSetRangeByRankAsync(key)).Result;
            var task = r.ContinueWith(p =>
              {
                return  hpcom.ConvetList<T>(r.Result);
              });
            return task;
        }

        public override Task<long> SortedSetLengthAsync(string key)
        {
            key = hpcom.AddSysCustomKey(key);
            return  hpcom.DoAsy(redis => redis.SortedSetLengthAsync(key)).Result;
        }

        public override Task<bool> SortedSetAddAsyncItem<T>(string key, T value, double score)
        {
            key = hpcom.AddSysCustomKey(key);
            return hpcom.DoAsy(redis => redis.SortedSetAddAsync(key, hpcom.Serializer<T>(value), score)).Result;
        }

        public override Task<bool> SortedSetRemoveAsyncItem<T>(string key, T value)
        {
            key = hpcom.AddSysCustomKey(key);
            return hpcom.DoAsy(redis => redis.SortedSetRemoveAsync(key, hpcom.Serializer(value))).Result;
        }

        public override Task<List<T>> SortedSetRangeByRankAsyncItem<T>(string key)
        {
            key = hpcom.AddSysCustomKey(key);
            var r = hpcom.DoAsy(redis => redis.SortedSetRangeByRankAsync(key)).Result;
            var task = r.ContinueWith(p =>
            {
                return hpcom.ConvetListItem<T>(r.Result);
            });
            return task;
        }

        ///// <summary>
        ///// 添加
        ///// </summary>
        ///// <param name="key"></param>
        ///// <param name="value"></param>
        ///// <param name="score"></param>
        //public async Task<bool> SortedSetAddAsync<T>(string key, T value, double score)
        //{
        //    key = hpcom.AddSysCustomKey(key);
        //    return await hpcom.Do(redis => redis.SortedSetAddAsync(key, hpcom.ConvertJson<T>(value), score));
        //}

        ///// <summary>
        ///// 删除
        ///// </summary>
        ///// <param name="key"></param>
        ///// <param name="value"></param>
        //public async Task<bool> SortedSetRemoveAsync<T>(string key, T value)
        //{
        //    key = hpcom.AddSysCustomKey(key);
        //    return await hpcom.Do(redis => redis.SortedSetRemoveAsync(key, hpcom.ConvertJson(value)));
        //}

        ///// <summary>
        ///// 获取全部
        ///// </summary>
        ///// <param name="key"></param>
        ///// <returns></returns>
        //public async Task<List<T>> SortedSetRangeByRankAsync<T>(string key)
        //{
        //    key = hpcom.AddSysCustomKey(key);
        //    var values = await hpcom.Do(redis => redis.SortedSetRangeByRankAsync(key));
        //    return hpcom.ConvetList<T>(values);
        //}

        ///// <summary>
        ///// 获取集合中的数量
        ///// </summary>
        ///// <param name="key"></param>
        ///// <returns></returns>
        //public async Task<long> SortedSetLengthAsync(string key)
        //{
        //    key = hpcom.AddSysCustomKey(key);
        //    return await hpcom.Do(redis => redis.SortedSetLengthAsync(key));
        //}




        #endregion 异步方法

        #endregion SortedSet 有序集合
    }
}
