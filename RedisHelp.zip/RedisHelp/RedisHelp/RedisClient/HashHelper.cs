﻿using IRedisClient;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace RedisClient
{
   public class HashHelper:HashStore
    {
        HelpCom hpcom =null;
       public HashHelper(string guid)
        {
            prxoy=RedisClientManger.GetPrxoy(guid);
            hpcom = prxoy.hpcom;
        }
        DBConnectProxy prxoy = null;

        /// <summary>
        /// 操作公用
        /// </summary>
        public HelpCom Hpcom
        {
            get
            {
                return hpcom;
            }

            set
            {
                hpcom = value;
            }
        }

        #region Hash

        #region 同步方法

        /// <summary>
        /// 判断某个数据是否已经被缓存
        /// </summary>
        /// <param name="key"></param>
        /// <param name="dataKey"></param>
        /// <returns></returns>
        public override bool HashExists(string key, string dataKey)
        {
            key = Hpcom.AddSysCustomKey(key);
            return Hpcom.Do(db => db.HashExists(key, dataKey));
        }

        /// <summary>
        /// 存储数据到hash表
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <param name="dataKey"></param>
        /// <param name="t"></param>
        /// <returns></returns>
        public override bool HashSet<T>(string key, string dataKey, T t)
        {
            key = Hpcom.AddSysCustomKey(key);
            return Hpcom.Do(db =>
            {
                string json = Hpcom.ConvertJson(t);
                return db.HashSet(key, dataKey, json);
            });
        }

        /// <summary>
        /// 移除hash中的某值
        /// </summary>
        /// <param name="key"></param>
        /// <param name="dataKey"></param>
        /// <returns></returns>
        public override bool HashDelete(string key, string dataKey)
        {
            key = Hpcom.AddSysCustomKey(key);
            return Hpcom.Do(db => db.HashDelete(key, dataKey));
        }

        /// <summary>
        /// 移除hash中的多个值
        /// </summary>
        /// <param name="key"></param>
        /// <param name="dataKeys"></param>
        /// <returns></returns>
        public override long HashDelete(string key, List<RedisValue> dataKeys)
        {
            key = Hpcom.AddSysCustomKey(key);
            //List<RedisValue> dataKeys1 = new List<RedisValue>() {"1","2"};
            return Hpcom.Do(db => db.HashDelete(key, dataKeys.ToArray()));
        }

        /// <summary>
        /// 从hash表获取数据
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <param name="dataKey"></param>
        /// <returns></returns>
        public override T HashGet<T>(string key, string dataKey)
        {
            key = Hpcom.AddSysCustomKey(key);
            return Hpcom.Do(db =>
            {
                string value = db.HashGet(key, dataKey);
                return Hpcom.ConvertObj<T>(value);
            });
        }

        /// <summary>
        /// 为数字增长val
        /// </summary>
        /// <param name="key"></param>
        /// <param name="dataKey"></param>
        /// <param name="val">可以为负</param>
        /// <returns>增长后的值</returns>
        public override double HashIncrement(string key, string dataKey, double val = 1)
        {
            key = Hpcom.AddSysCustomKey(key);
            return Hpcom.Do(db => db.HashIncrement(key, dataKey, val));
        }

        /// <summary>
        /// 为数字减少val
        /// </summary>
        /// <param name="key"></param>
        /// <param name="dataKey"></param>
        /// <param name="val">可以为负</param>
        /// <returns>减少后的值</returns>
        public override double HashDecrement(string key, string dataKey, double val = 1)
        {
            key = Hpcom.AddSysCustomKey(key);
            return Hpcom.Do(db => db.HashDecrement(key, dataKey, val));
        }

        /// <summary>
        /// 获取hashkey所有Redis key
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <returns></returns>
        public override List<T> HashKeys<T>(string key)
        {
            key = Hpcom.AddSysCustomKey(key);
            return Hpcom.Do(db =>
            {
                RedisValue[] values = db.HashKeys(key);
                return Hpcom.ConvetList<T>(values);
            });
        }
        public override bool HashSetItem<T>(string key, string dataKey, T t)
        {
            key = Hpcom.AddSysCustomKey(key);
            return Hpcom.Do(db =>
            {
                byte[] data = Hpcom.Serializer(t);
                return db.HashSet(key, dataKey, data);
            });
        }

        public override T HashGetItem<T>(string key, string dataKey)
        {
            key = Hpcom.AddSysCustomKey(key);
            return Hpcom.Do(db =>
            {
                byte[] value = db.HashGet(key, dataKey);
                return Hpcom.DeSerializer<T>(value);
            });
        }

        #endregion 同步方法

        #region 异步方法
        public override Task<bool> HashExistsAsync(string key, string dataKey)
        {
             key = Hpcom.AddSysCustomKey(key);
             return  Hpcom.DoAsy(db => db.HashExistsAsync(key, dataKey).Result);
        }

        public override Task<bool> HashSetAsync<T>(string key, string dataKey, T t)
        {
            key = Hpcom.AddSysCustomKey(key);
            return  Hpcom.DoAsy(db =>
            {
                string json = Hpcom.ConvertJson(t);
                return db.HashSetAsync(key, dataKey, json).Result;
            });
        }

        public override Task<bool> HashDeleteAsync(string key, string dataKey)
        {
            key = Hpcom.AddSysCustomKey(key);
            return  Hpcom.DoAsy(db => db.HashDeleteAsync(key, dataKey)).Result;
        }

        public override Task<T> HashGeAsync<T>(string key, string dataKey)
        {
            key = Hpcom.AddSysCustomKey(key);
            var result = Hpcom.DoAsy(db => db.HashGetAsync(key, dataKey)).Result;
            var task = result.ContinueWith(p =>
              {
                 return  Hpcom.ConvertObj<T>(result.Result);
              });
            return task;
        }

        public override Task<double> HashIncrementAsync(string key, string dataKey, double val = 1)
        {
            key = Hpcom.AddSysCustomKey(key);
            return  Hpcom.DoAsy(db => db.HashIncrementAsync(key, dataKey, val)).Result;
        }

        public override Task<double> HashDecrementAsync(string key, string dataKey, double val = 1)
        {
            key = Hpcom.AddSysCustomKey(key);
            return  Hpcom.DoAsy(db => db.HashDecrementAsync(key, dataKey, val)).Result;
        }

        public override Task<List<T>> HashKeysAsync<T>(string key)
        {
            key = Hpcom.AddSysCustomKey(key);
           var ts = Hpcom.DoAsy(db => db.HashKeysAsync(key)).Result;
           var task= ts.ContinueWith(
                (v =>
                {
                    return Hpcom.ConvetList<T>(ts.Result);

                }
                ));
            return task;
            // RedisValue[] values =  Hpcom.DoAsy(db => db.HashKeysAsync(key)).Result;
            // return Hpcom.ConvetList<T>(values);
        }

        public override Task<T> HashGeAsyncItem<T>(string key, string dataKey)
        {
            key = Hpcom.AddSysCustomKey(key);
            var result = Hpcom.DoAsy(db => db.HashGetAsync(key, dataKey)).Result;
            var task = result.ContinueWith(p =>
            {
                return Hpcom.DeSerializer<T>(result.Result);
            });
            return task;
        }

        public override Task<List<T>> HashKeysAsyncItem<T>(string key)
        {
            key = Hpcom.AddSysCustomKey(key);
            var ts = Hpcom.DoAsy(db => db.HashKeysAsync(key)).Result;
            var task = ts.ContinueWith(
                 (v =>
                 {
                     return Hpcom.ConvetListItem<T>(ts.Result);

                 }
                 ));
            return task;
        }
        ///// <summary>
        ///// 判断某个数据是否已经被缓存
        ///// </summary>
        ///// <param name="key"></param>
        ///// <param name="dataKey"></param>
        ///// <returns></returns>
        //public async Task<bool> HashExistsAsync(string key, string dataKey)
        //{
        //    key = Hpcom.AddSysCustomKey(key);
        //    return await Hpcom.Do(db => db.HashExistsAsync(key, dataKey));
        //}

        ///// <summary>
        ///// 存储数据到hash表
        ///// </summary>
        ///// <typeparam name="T"></typeparam>
        ///// <param name="key"></param>
        ///// <param name="dataKey"></param>
        ///// <param name="t"></param>
        ///// <returns></returns>
        //public async Task<bool> HashSetAsync<T>(string key, string dataKey, T t)
        //{
        //    key = Hpcom.AddSysCustomKey(key);
        //    return await Hpcom.Do(db =>
        //    {
        //        string json = Hpcom.ConvertJson(t);
        //        return db.HashSetAsync(key, dataKey, json);
        //    });
        //}

        ///// <summary>
        ///// 移除hash中的某值
        ///// </summary>
        ///// <param name="key"></param>
        ///// <param name="dataKey"></param>
        ///// <returns></returns>
        //public async Task<bool> HashDeleteAsync(string key, string dataKey)
        //{
        //    key = Hpcom.AddSysCustomKey(key);
        //    return await Hpcom.Do(db => db.HashDeleteAsync(key, dataKey));
        //}

        ///// <summary>
        ///// 移除hash中的多个值
        ///// </summary>
        ///// <param name="key"></param>
        ///// <param name="dataKeys"></param>
        ///// <returns></returns>
        //public async Task<long> HashDeleteAsync(string key, List<RedisValue> dataKeys)
        //{
        //    key = Hpcom.AddSysCustomKey(key);
        //    //List<RedisValue> dataKeys1 = new List<RedisValue>() {"1","2"};
        //    return await Hpcom.Do(db => db.HashDeleteAsync(key, dataKeys.ToArray()));
        //}

        ///// <summary>
        ///// 从hash表获取数据
        ///// </summary>
        ///// <typeparam name="T"></typeparam>
        ///// <param name="key"></param>
        ///// <param name="dataKey"></param>
        ///// <returns></returns>
        //public async Task<T> HashGeAsync<T>(string key, string dataKey)
        //{
        //    key = Hpcom.AddSysCustomKey(key);
        //    string value = await Hpcom.Do(db => db.HashGetAsync(key, dataKey));
        //    return Hpcom.ConvertObj<T>(value);
        //}

        ///// <summary>
        ///// 为数字增长val
        ///// </summary>
        ///// <param name="key"></param>
        ///// <param name="dataKey"></param>
        ///// <param name="val">可以为负</param>
        ///// <returns>增长后的值</returns>
        //public async Task<double> HashIncrementAsync(string key, string dataKey, double val = 1)
        //{
        //    key = Hpcom.AddSysCustomKey(key);
        //    return await Hpcom.Do(db => db.HashIncrementAsync(key, dataKey, val));
        //}

        ///// <summary>
        ///// 为数字减少val
        ///// </summary>
        ///// <param name="key"></param>
        ///// <param name="dataKey"></param>
        ///// <param name="val">可以为负</param>
        ///// <returns>减少后的值</returns>
        //public async Task<double> HashDecrementAsync(string key, string dataKey, double val = 1)
        //{
        //    key = Hpcom.AddSysCustomKey(key);
        //    return await Hpcom.Do(db => db.HashDecrementAsync(key, dataKey, val));
        //}

        ///// <summary>
        ///// 获取hashkey所有Redis key
        ///// </summary>
        ///// <typeparam name="T"></typeparam>
        ///// <param name="key"></param>
        ///// <returns></returns>
        //public async Task<List<T>> HashKeysAsync<T>(string key)
        //{
        //    key = Hpcom.AddSysCustomKey(key);
        //    RedisValue[] values = await Hpcom.Do(db => db.HashKeysAsync(key));
        //    return Hpcom.ConvetList<T>(values);
        //}





        #endregion 异步方法

        #endregion Hash
    }
}
