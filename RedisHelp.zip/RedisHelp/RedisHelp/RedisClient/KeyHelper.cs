﻿using IRedisClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RedisClient
{
  public  class KeyHelper:KeyStore
    {
        public KeyHelper(string guid)
        {
            prxoy=  RedisClientManger.GetPrxoy(guid);
            hpcom = prxoy.hpcom;
        }
        DBConnectProxy prxoy = null;
        HelpCom hpcom = null;

        public HelpCom Hpcom
        {
            get
            {
                return hpcom;
            }

            set
            {
                hpcom = value;
            }
        }
        #region key

        /// <summary>
        /// 删除单个key
        /// </summary>
        /// <param name="key">redis key</param>
        /// <returns>是否删除成功</returns>
        public override bool KeyDelete(string key)
        {
            key = Hpcom.AddSysCustomKey(key);
            return Hpcom.Do(db => db.KeyDelete(key));
        }

        /// <summary>
        /// 删除多个key
        /// </summary>
        /// <param name="keys">rediskey</param>
        /// <returns>成功删除的个数</returns>
        public override long KeyDelete(List<string> keys)
        {
            List<string> newKeys = keys.Select(Hpcom.AddSysCustomKey).ToList();
            return Hpcom.Do(db => db.KeyDelete(Hpcom.ConvertRedisKeys(newKeys)));
        }

        /// <summary>
        /// 判断key是否存储
        /// </summary>
        /// <param name="key">redis key</param>
        /// <returns></returns>
        public override bool KeyExists(string key)
        {
            key = Hpcom.AddSysCustomKey(key);
            return Hpcom.Do(db => db.KeyExists(key));
        }

        /// <summary>
        /// 重新命名key
        /// </summary>
        /// <param name="key">就的redis key</param>
        /// <param name="newKey">新的redis key</param>
        /// <returns></returns>
        public override bool KeyRename(string key, string newKey)
        {
            key = Hpcom.AddSysCustomKey(key);
            return Hpcom.Do(db => db.KeyRename(key, newKey));
        }

        /// <summary>
        /// 设置Key的时间
        /// </summary>
        /// <param name="key">redis key</param>
        /// <param name="expiry"></param>
        /// <returns></returns>
        public override bool KeyExpire(string key, TimeSpan? expiry = default(TimeSpan?))
        {
            key = Hpcom.AddSysCustomKey(key);
            return Hpcom.Do(db => db.KeyExpire(key, expiry));
        }

        #endregion key
    }
}
