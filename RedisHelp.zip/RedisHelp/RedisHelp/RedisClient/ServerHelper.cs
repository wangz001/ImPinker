﻿using IRedisClient;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RedisClient
{
   public class ServerHelper:ServerStore
    {
        public int DbNum { get; set; }
        //private readonly ConnectionMultiplexer _conn;
        DBConnectProxy prxoy = null;
        HelpCom hpcom = null;
        public ServerHelper(string guid)
        {
            prxoy = RedisClientManger.GetPrxoy(guid);
            hpcom = prxoy.hpcom;
        }
        #region 其他

        public override ITransaction CreateTransaction()
        {
            return GetDatabase().CreateTransaction();
        }

        public override IDatabase GetDatabase()
        {
            return hpcom.GetConnection().GetDatabase(DbNum);
        }

        public override IServer GetServer(string hostAndPort)
        {
            return hpcom.GetConnection().GetServer(hostAndPort);
        }

        

        #endregion 其他
    }
}
