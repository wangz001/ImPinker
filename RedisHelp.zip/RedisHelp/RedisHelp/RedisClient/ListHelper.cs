﻿using IRedisClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RedisClient
{
   public class ListHelper:ListStore
    {
        HelpCom hpcom = null;
        public ListHelper(string guid)
        {
            prxoy = RedisClientManger.GetPrxoy(guid);
            hpcom = prxoy.hpcom;
        }
        DBConnectProxy prxoy = null;
        public HelpCom Hpcom
        {
            get
            {
                return hpcom;
            }

            set
            {
                hpcom = value;
            }
        }
        #region List

        #region 同步方法

        /// <summary>
        /// 移除指定ListId的内部List的值
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public override void ListRemove<T>(string key, T value)
        {
            key = Hpcom.AddSysCustomKey(key);
            Hpcom.Do(db => db.ListRemove(key, Hpcom.ConvertJson(value)));
        }

        /// <summary>
        /// 获取指定key的List
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public override List<T> ListRange<T>(string key)
        {
            key = Hpcom.AddSysCustomKey(key);
            return Hpcom.Do(redis =>
            {
                var values = redis.ListRange(key);
                return Hpcom.ConvetList<T>(values);
            });
        }

        /// <summary>
        /// 入队
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public override void ListRightPush<T>(string key, T value)
        {
            key = Hpcom.AddSysCustomKey(key);
            Hpcom.Do(db => db.ListRightPush(key, Hpcom.ConvertJson(value)));
        }

        /// <summary>
        /// 出队
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <returns></returns>
        public override T ListRightPop<T>(string key)
        {
            key = Hpcom.AddSysCustomKey(key);
            return Hpcom.Do(db =>
            {
                var value = db.ListRightPop(key);
                return Hpcom.ConvertObj<T>(value);
            });
        }

        /// <summary>
        /// 入栈
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public override void ListLeftPush<T>(string key, T value)
        {
            key = Hpcom.AddSysCustomKey(key);
            Hpcom.Do(db => db.ListLeftPush(key, Hpcom.ConvertJson(value)));
        }

        /// <summary>
        /// 出栈
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <returns></returns>
        public override T ListLeftPop<T>(string key)
        {
            key = Hpcom.AddSysCustomKey(key);
            return Hpcom.Do(db =>
            {
                var value = db.ListLeftPop(key);
                return Hpcom.ConvertObj<T>(value);
            });
        }

        /// <summary>
        /// 获取集合中的数量
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public override long ListLength(string key)
        {
            key = Hpcom.AddSysCustomKey(key);
            return Hpcom.Do(redis => redis.ListLength(key));
        }
        public override void ListRemoveItem<T>(string key, T value)
        {
            key = Hpcom.AddSysCustomKey(key);
            Hpcom.Do(db => db.ListRemove(key, Hpcom.Serializer(value)));
        }

        public override List<T> ListRangeItem<T>(string key)
        {
            key = Hpcom.AddSysCustomKey(key);
            return Hpcom.Do(redis =>
            {
                var values = redis.ListRange(key);
                return Hpcom.ConvetListItem<T>(values);
            });
        }

        public override void ListRightPushItem<T>(string key, T value)
        {
            key = Hpcom.AddSysCustomKey(key);
            Hpcom.Do(db => db.ListRightPush(key, Hpcom.Serializer(value)));
        }

        public override T ListRightPopItem<T>(string key)
        {
            key = Hpcom.AddSysCustomKey(key);
            return Hpcom.Do(db =>
            {
                var value = db.ListRightPop(key);
                return Hpcom.DeSerializer<T>(value);
            });
        }

        public override void ListLeftPushItem<T>(string key, T value)
        {
            key = Hpcom.AddSysCustomKey(key);
            Hpcom.Do(db => db.ListLeftPush(key, Hpcom.Serializer(value)));
        }

        public override T ListLeftPopItem<T>(string key)
        {
            key = Hpcom.AddSysCustomKey(key);
            return Hpcom.Do(db =>
            {
                var value = db.ListLeftPop(key);
                return Hpcom.DeSerializer<T>(value);
            });
        }

        public override Task<long> ListRemoveAsync<T>(string key, T value)
        {
            key = Hpcom.AddSysCustomKey(key);
            return  Hpcom.DoAsy(db => db.ListRemoveAsync(key, Hpcom.ConvertJson(value))).Result;
        }

        public override Task<List<T>> ListRangeAsync<T>(string key)
        {
            key = Hpcom.AddSysCustomKey(key);
            var values =Hpcom.DoAsy(redis => redis.ListRangeAsync(key)).Result;
            Task<List<T>> ts = values.ContinueWith((P) =>
              {
                  var r = values.Result;
                  return Hpcom.ConvetList<T>(r);
              });
            return ts;
        }

        public override Task<long> ListRightPushAsync<T>(string key, T value)
        {
            key = Hpcom.AddSysCustomKey(key);
            return  Hpcom.DoAsy(db => db.ListRightPushAsync(key, Hpcom.ConvertJson(value))).Result;
        }

        public override Task<T> ListRightPopAsync<T>(string key)
        {
            key = Hpcom.AddSysCustomKey(key);
            var value =Hpcom.DoAsy(db => db.ListRightPopAsync(key)).Result;
            var task = value.ContinueWith(p =>
              {
                  return Hpcom.ConvertObj<T>(value.Result);
              });
            return task;
          //  return Hpcom.ConvertObj<T>(value);
        }

        public override Task<long> ListLeftPushAsync<T>(string key, T value)
        {
            key = Hpcom.AddSysCustomKey(key);
            return  Hpcom.DoAsy(db => db.ListLeftPushAsync(key, Hpcom.ConvertJson(value))).Result;
        }

        public override Task<T> ListLeftPopAsync<T>(string key)
        {
            key = Hpcom.AddSysCustomKey(key);
            var value = Hpcom.DoAsy(db => db.ListLeftPopAsync(key)).Result;
            var task = value.ContinueWith(p =>
              {
                  return Hpcom.ConvertObj<T>(value.Result);
              });
            return task;
        }

        public override Task<long> ListLengthAsync(string key)
        {
            key = Hpcom.AddSysCustomKey(key);
            return  Hpcom.DoAsy(redis => redis.ListLengthAsync(key)).Result;
        }

        public override Task<List<T>> ListRangeAsyncItems<T>(string key)
        {
            key = Hpcom.AddSysCustomKey(key);
            var values = Hpcom.DoAsy(redis => redis.ListRangeAsync(key)).Result;
            Task<List<T>> ts = values.ContinueWith((P) =>
            {
                var r = values.Result;
                return Hpcom.ConvetListItem<T>(r);
            });
            return ts;
        }

        public override Task<T> ListRightPopAsyncItem<T>(string key)
        {
            key = Hpcom.AddSysCustomKey(key);
            var value = Hpcom.DoAsy(db => db.ListRightPopAsync(key)).Result;
            var task = value.ContinueWith(p =>
            {
                return Hpcom.DeSerializer<T>(value.Result);
            });
            return task;
        }

        public override Task<T> ListLeftPopAsyncItem<T>(string key)
        {
            key = Hpcom.AddSysCustomKey(key);
            var value = Hpcom.DoAsy(db => db.ListLeftPopAsync(key)).Result;
            var task = value.ContinueWith(p =>
            {
                return Hpcom.DeSerializer<T>(value.Result);
            });
            return task;
        }
        #endregion 同步方法

        #region 异步方法

        ///// <summary>
        ///// 移除指定ListId的内部List的值
        ///// </summary>
        ///// <param name="key"></param>
        ///// <param name="value"></param>
        //public async Task<long> ListRemoveAsync<T>(string key, T value)
        //{
        //    key = Hpcom.AddSysCustomKey(key);
        //    return await Hpcom.Do(db => db.ListRemoveAsync(key, Hpcom.ConvertJson(value)));
        //}

        ///// <summary>
        ///// 获取指定key的List
        ///// </summary>
        ///// <param name="key"></param>
        ///// <returns></returns>
        //public async Task<List<T>> ListRangeAsync<T>(string key)
        //{
        //    key = Hpcom.AddSysCustomKey(key);
        //    var values = await Hpcom.Do(redis => redis.ListRangeAsync(key));
        //    return Hpcom.ConvetList<T>(values);
        //}

        ///// <summary>
        ///// 入队
        ///// </summary>
        ///// <param name="key"></param>
        ///// <param name="value"></param>
        //public async Task<long> ListRightPushAsync<T>(string key, T value)
        //{
        //    key = Hpcom.AddSysCustomKey(key);
        //    return await Hpcom.Do(db => db.ListRightPushAsync(key, Hpcom.ConvertJson(value)));
        //}

        ///// <summary>
        ///// 出队
        ///// </summary>
        ///// <typeparam name="T"></typeparam>
        ///// <param name="key"></param>
        ///// <returns></returns>
        //public async Task<T> ListRightPopAsync<T>(string key)
        //{
        //    key = Hpcom.AddSysCustomKey(key);
        //    var value = await Hpcom.Do(db => db.ListRightPopAsync(key));
        //    return Hpcom.ConvertObj<T>(value);
        //}

        ///// <summary>
        ///// 入栈
        ///// </summary>
        ///// <typeparam name="T"></typeparam>
        ///// <param name="key"></param>
        ///// <param name="value"></param>
        //public async Task<long> ListLeftPushAsync<T>(string key, T value)
        //{
        //    key = Hpcom.AddSysCustomKey(key);
        //    return await Hpcom.Do(db => db.ListLeftPushAsync(key, Hpcom.ConvertJson(value)));
        //}

        ///// <summary>
        ///// 出栈
        ///// </summary>
        ///// <typeparam name="T"></typeparam>
        ///// <param name="key"></param>
        ///// <returns></returns>
        //public async Task<T> ListLeftPopAsync<T>(string key)
        //{
        //    key = Hpcom.AddSysCustomKey(key);
        //    var value = await Hpcom.Do(db => db.ListLeftPopAsync(key));
        //    return Hpcom.ConvertObj<T>(value);
        //}

        ///// <summary>
        ///// 获取集合中的数量
        ///// </summary>
        ///// <param name="key"></param>
        ///// <returns></returns>
        //public async Task<long> ListLengthAsync(string key)
        //{
        //    key = Hpcom.AddSysCustomKey(key);
        //    return await Hpcom.Do(redis => redis.ListLengthAsync(key));
        //}



        #endregion 异步方法

        #endregion List
    }
}
