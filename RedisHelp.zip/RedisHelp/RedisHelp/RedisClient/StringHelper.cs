﻿using IRedisClient;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace RedisClient
{
  public  class StringHelper: StringStore
    {
      public StringHelper(string guid)
        {
            prxoy = RedisClientManger.GetPrxoy(guid);
            hpcom = prxoy.hpcom;
        }
        DBConnectProxy prxoy = null;
        HelpCom hpcom = null;

        public HelpCom Hpcom
        {
            get
            {
                return hpcom;
            }

            set
            {
                hpcom = value;
            }
        }
        #region String

        #region 同步方法

        /// <summary>
        /// 保存单个key value
        /// </summary>
        /// <param name="key">Redis Key</param>
        /// <param name="value">保存的值</param>
        /// <param name="expiry">过期时间</param>
        /// <returns></returns>
        public override bool StringSet(string key, string value, TimeSpan? expiry = default(TimeSpan?))
        {
            key = hpcom.AddSysCustomKey(key);
            return hpcom.Do(db => db.StringSet(key, value, expiry));
        }

        /// <summary>
        /// 保存多个key value
        /// </summary>
        /// <param name="keyValues">键值对</param>
        /// <returns></returns>
        public override bool StringSet(List<KeyValuePair<RedisKey, RedisValue>> keyValues)
        {
            List<KeyValuePair<RedisKey, RedisValue>> newkeyValues =
                keyValues.Select(p => new KeyValuePair<RedisKey, RedisValue>(hpcom.AddSysCustomKey(p.Key), p.Value)).ToList();
            return hpcom.Do(db => db.StringSet(newkeyValues.ToArray()));
        }

        /// <summary>
        /// 保存一个对象
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <param name="obj"></param>
        /// <param name="expiry"></param>
        /// <returns></returns>
        public override bool StringSet<T>(string key, T obj, TimeSpan? expiry = default(TimeSpan?))
        {
            key = hpcom.AddSysCustomKey(key);
            string json = hpcom.ConvertJson(obj);
            return hpcom.Do(db => db.StringSet(key, json, expiry));
        }

        /// <summary>
        /// 获取单个key的值
        /// </summary>
        /// <param name="key">Redis Key</param>
        /// <returns></returns>
        public override string StringGet(string key)
        {
            key = hpcom.AddSysCustomKey(key);
            return hpcom.Do(db => db.StringGet(key));
        }

        /// <summary>
        /// 获取多个Key
        /// </summary>
        /// <param name="listKey">Redis Key集合</param>
        /// <returns></returns>
        public override RedisValue[] StringGet(List<string> listKey)
        {
            List<string> newKeys = listKey.Select(hpcom.AddSysCustomKey).ToList();
            return hpcom.Do(db => db.StringGet(hpcom.ConvertRedisKeys(newKeys)));
        }

        /// <summary>
        /// 获取一个key的对象
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <returns></returns>
        public override T StringGet<T>(string key)
        {
            key = hpcom.AddSysCustomKey(key);
            return hpcom.Do(db => hpcom.ConvertObj<T>(db.StringGet(key)));
        }

        /// <summary>
        /// 为数字增长val
        /// </summary>
        /// <param name="key"></param>
        /// <param name="val">可以为负</param>
        /// <returns>增长后的值</returns>
        public override double StringIncrement(string key, double val = 1)
        {
            key = hpcom.AddSysCustomKey(key);
            return hpcom.Do(db => db.StringIncrement(key, val));
        }

        /// <summary>
        /// 为数字减少val
        /// </summary>
        /// <param name="key"></param>
        /// <param name="val">可以为负</param>
        /// <returns>减少后的值</returns>
        public override double StringDecrement(string key, double val = 1)
        {
            key = hpcom.AddSysCustomKey(key);
            return hpcom.Do(db => db.StringDecrement(key, val));
        }
        /// <summary>
        /// 二进制存储
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <param name="obj"></param>
        /// <param name="expiry"></param>
        /// <returns></returns>
        public override bool StringSetItem<T>(string key, T obj, TimeSpan? expiry = default(TimeSpan?))
        {
            key = hpcom.AddSysCustomKey(key);
            byte[] data = hpcom.Serializer(obj);
            return hpcom.Do(db => db.StringSet(key, data, expiry));
        }

        /// <summary>
        /// 二进制存储
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <returns></returns>
        public override T StringGetItem<T>(string key)
        {
            key = hpcom.AddSysCustomKey(key);
            return hpcom.Do(db => hpcom.DeSerializer<T>(db.StringGet(key)));
        }

        #endregion 同步方法

        #region 异步方法

        /// <summary>
        /// 保存单个key value
        /// </summary>
        /// <param name="key">Redis Key</param>
        /// <param name="value">保存的值</param>
        /// <param name="expiry">过期时间</param>
        /// <returns></returns>
        public  override Task<bool> StringSetAsync(string key, string value, TimeSpan? expiry = default(TimeSpan?))
        {


            return hpcom.DoAsy(db => db.StringSetAsync(key, value, expiry).Result);
           //return hpcom.DoAsy(db => db.StringSetAsync(key, value, expiry)).Result.Result;
           // return await hpcom.Do(db => db.StringSetAsync(key, value, expiry));
        }

        public override Task<bool> StringSetAsync(List<KeyValuePair<RedisKey, RedisValue>> keyValues)
        {
            List<KeyValuePair<RedisKey, RedisValue>> newkeyValues =
            keyValues.Select(p => new KeyValuePair<RedisKey, RedisValue>(hpcom.AddSysCustomKey(p.Key), p.Value)).ToList();
            return hpcom.DoAsy(db => db.StringSetAsync(newkeyValues.ToArray()).Result);
        }

        public override Task<bool> StringSetAsync<T>(string key, T obj, TimeSpan? expiry = default(TimeSpan?))
        {
            key = hpcom.AddSysCustomKey(key);
            string json = hpcom.ConvertJson(obj);
           // return await hpcom.Do(db => db.StringSetAsync(key, json, expiry));
            return hpcom.DoAsy(db => db.StringSetAsync( key,json,expiry).Result);
        }

        public override Task<string> StringGetAsync(string key)
        {
            key = hpcom.AddSysCustomKey(key);
            return hpcom.DoAsy(db => db.StringGetAsync(key).Result.ToString());
        }

        public override Task<RedisValue[]> StringGetAsync(List<string> listKey)
        {
            List<string> newKeys = listKey.Select(hpcom.AddSysCustomKey).ToList();
            return hpcom.DoAsy(db => db.StringGetAsync(hpcom.ConvertRedisKeys(newKeys)).Result);
        }

        public override Task<T> StringGetAsync<T>(string key)
        {
            key = hpcom.AddSysCustomKey(key);
            var result = hpcom.DoAsy(db => db.StringGetAsync(key)).Result;
            var task = result.ContinueWith(p =>
              {
                  return hpcom.ConvertObj<T>(result.Result);
              });
            return task;
        }

        public override Task<double> StringIncrementAsync(string key, double val = 1)
        {
            key = hpcom.AddSysCustomKey(key);
             return  hpcom.DoAsy(db => db.StringIncrementAsync(key, val).Result);
        }

        public override Task<double> StringDecrementAsync(string key, double val = 1)
        {
            key = hpcom.AddSysCustomKey(key);
            return  hpcom.DoAsy(db => db.StringDecrementAsync(key, val).Result);
        }

        public override Task<bool> StringSetAsyncItem<T>(string key, T obj, TimeSpan? expiry = default(TimeSpan?))
        {
            key = hpcom.AddSysCustomKey(key);
            var json = hpcom.Serializer(obj);
           
            return hpcom.DoAsy(db => db.StringSetAsync(key, json, expiry).Result);
        }

        public override Task<T> StringGetAsyncItem<T>(string key)
        {
            key = hpcom.AddSysCustomKey(key);
            var result = hpcom.DoAsy(db => db.StringGetAsync(key)).Result;
            var task = result.ContinueWith(p =>
            {
                return hpcom.DeSerializer<T>(result.Result);
            });
            return task;
        }

        ///// <summary>
        ///// 保存多个key value
        ///// </summary>
        ///// <param name="keyValues">键值对</param>
        ///// <returns></returns>
        //public async Task<bool> StringSetAsync(List<KeyValuePair<RedisKey, RedisValue>> keyValues)
        //{
        //    List<KeyValuePair<RedisKey, RedisValue>> newkeyValues =
        //        keyValues.Select(p => new KeyValuePair<RedisKey, RedisValue>(hpcom.AddSysCustomKey(p.Key), p.Value)).ToList();
        //    return hpcom.DoAsy(db => db => db.StringSetAsync(newkeyValues.ToArray()).Result);
        //   // return await hpcom.Do(db => db.StringSetAsync(newkeyValues.ToArray()));
        //}

        ///// <summary>
        ///// 保存一个对象
        ///// </summary>
        ///// <typeparam name="T"></typeparam>
        ///// <param name="key"></param>
        ///// <param name="obj"></param>
        ///// <param name="expiry"></param>
        ///// <returns></returns>
        //public async Task<bool> StringSetAsync<T>(string key, T obj, TimeSpan? expiry = default(TimeSpan?))
        //{
        //    key = hpcom.AddSysCustomKey(key);
        //    string json = hpcom.ConvertJson(obj);
        //    return await hpcom.Do(db => db.StringSetAsync(key, json, expiry));
        //}

        ///// <summary>
        ///// 获取单个key的值
        ///// </summary>
        ///// <param name="key">Redis Key</param>
        ///// <returns></returns>
        //public async Task<string> StringGetAsync(string key)
        //{
        //    key = hpcom.AddSysCustomKey(key);
        //    return await hpcom.Do(db => db.StringGetAsync(key));
        //}

        ///// <summary>
        ///// 获取多个Key
        ///// </summary>
        ///// <param name="listKey">Redis Key集合</param>
        ///// <returns></returns>
        //public async Task<RedisValue[]> StringGetAsync(List<string> listKey)
        //{
        //    List<string> newKeys = listKey.Select(hpcom.AddSysCustomKey).ToList();
        //    return await hpcom.Do(db => db.StringGetAsync(hpcom.ConvertRedisKeys(newKeys)));
        //}

        ///// <summary>
        ///// 获取一个key的对象
        ///// </summary>
        ///// <typeparam name="T"></typeparam>
        ///// <param name="key"></param>
        ///// <returns></returns>
        //public async Task<T> StringGetAsync<T>(string key)
        //{
        //    key = hpcom.AddSysCustomKey(key);
        //    string result = await hpcom.Do(db => db.StringGetAsync(key));
        //    return hpcom.ConvertObj<T>(result);
        //}

        ///// <summary>
        ///// 为数字增长val
        ///// </summary>
        ///// <param name="key"></param>
        ///// <param name="val">可以为负</param>
        ///// <returns>增长后的值</returns>
        //public async Task<double> StringIncrementAsync(string key, double val = 1)
        //{
        //    key = hpcom.AddSysCustomKey(key);
        //    return await hpcom.Do(db => db.StringIncrementAsync(key, val));
        //}

        ///// <summary>
        ///// 为数字减少val
        ///// </summary>
        ///// <param name="key"></param>
        ///// <param name="val">可以为负</param>
        ///// <returns>减少后的值</returns>
        //public async Task<double> StringDecrementAsync(string key, double val = 1)
        //{
        //    key = hpcom.AddSysCustomKey(key);
        //    return await hpcom.Do(db => db.StringDecrementAsync(key, val));
        //}



        #endregion 异步方法

        #endregion String
    }
}
