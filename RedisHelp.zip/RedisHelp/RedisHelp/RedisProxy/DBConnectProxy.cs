﻿using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RedisClient
{
   public class DBConnectProxy
    {
        
        public HelpCom hpcom = null;
        public DateTime curTime = DateTime.Now;
        
    }
}
