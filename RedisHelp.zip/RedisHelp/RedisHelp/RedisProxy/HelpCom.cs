﻿using MsgPack.Serialization;
using Newtonsoft.Json;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Threading.Tasks;

namespace RedisClient
{
    /// <summary>
    /// 该类尽可能独立
    /// </summary>
  public  class HelpCom
    {
        #region 辅助方法
        private string CustomKey;
        private  ConnectionMultiplexer _conn;
        public int DbNum { get; set; }
        public HelpCom(ConnectionMultiplexer con,string customKey)
        {
            CustomKey = customKey;
            _conn = con;

        }

        public void SetCon(ConnectionMultiplexer con)
        {
            _conn = con;
        }
        public  void SetKey(string custom)
        {
            CustomKey = custom;
        }
       

        public string AddSysCustomKey(string oldKey)
        {
            var prefixKey = CustomKey ?? RedisClientManger.SysCustomKey;
            return prefixKey + oldKey;
        }

        public T Do<T>(Func<IDatabase, T> func)
        {  
          
            var database = _conn.GetDatabase(DbNum);
            return func(database);
        }
        public Task<T> DoAsy<T>(Func<IDatabase, T> func)
        {
            

            var t = Task.Factory.StartNew<T>(()=>
              {

                    var database = _conn.GetDatabase(DbNum);
                    var r=   func(database);
                  return r;
              }
               );
            return t;
        }

        public string ConvertJson<T>(T value)
        {
            string result = value is string ? value.ToString() : JsonConvert.SerializeObject(value);
            return result;
        }
        public byte[] Serializer<T>(T obj)
        {
            var serializer = SerializationContext.Default.GetSerializer<T>();
            MemoryStream stream = new MemoryStream();
            serializer.Pack(stream, obj);
            byte[] bytes = stream.ToArray();
            stream.Close();
            return bytes;
        }
        public T DeSerializer<T>(byte[]data)
        {
            var serializer = SerializationContext.Default.GetSerializer<T>();
            MemoryStream stream = new MemoryStream(data);
            T unpackedObject = serializer.Unpack(stream);
            return unpackedObject;
        }

        public T ConvertObj<T>(RedisValue value)
        {
            return JsonConvert.DeserializeObject<T>(value);
        }

        public List<T> ConvetList<T>(RedisValue[] values)
        {
            List<T> result = new List<T>();
            foreach (var item in values)
            {
                var model = ConvertObj<T>(item);
                result.Add(model);
            }
            return result;
        }
        public List<T> ConvetListItem<T>(RedisValue[] values)
        {
            List<T> result = new List<T>();
            foreach (var item in values)
            {
                var model = DeSerializer<T>(item);
                result.Add(model);
            }
            return result;
        }

        public RedisKey[] ConvertRedisKeys(List<string> redisKeys)
        {
            return redisKeys.Select(redisKey => (RedisKey)redisKey).ToArray();
        }

        public ConnectionMultiplexer GetConnection()
        {
            return _conn;
        }

        #endregion 辅助方法
    }
}
