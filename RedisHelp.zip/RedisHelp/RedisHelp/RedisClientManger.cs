﻿using IRedisClient;
using StackExchange.Redis;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RedisClient
{
    /// <summary>
    /// 管理实例与连接缓存
    /// 检查关闭连接
    /// 读取配置
    /// 配置内容：
    /// 设置一个标记Key
    /// 连接字符串
    /// 是否自动检测关闭（AutoClose主要是服务端程序应用）
    /// 连接关闭时间长度ConnectionTime
    /// 每次使用时会刷新时间，程序检测使用的设计与当前时间间隔长度，超过则关闭
    /// </summary>
    public class RedisClientManger
    {
      
        //系统自定义Key前缀
         public static readonly string SysCustomKey = ConfigurationManager.AppSettings["redisKey"] ?? "";

        //"127.0.0.1:6379,allowadmin=true
        private static readonly string RedisConnectionString = ConfigurationManager.ConnectionStrings["RedisExchangeHosts"] == null ? "" : ConfigurationManager.ConnectionStrings["RedisExchangeHosts"].ConnectionString;
        private static  readonly string CloseTimeOut = ConfigurationManager.AppSettings["ConnectionTime"] ?? "600";
        private static readonly string IsAutoClose = ConfigurationManager.AppSettings["AutoClose"] ?? "0";
        private static readonly object Locker = new object();
        private static readonly object lock_Thread = new object();
        private static ConnectionMultiplexer _instance;
        static  Thread checkClose = null;
       
        /// <summary>
        /// 一个连接一个对象
        /// 同一个连接字符串共享一个连接
        /// </summary>
        private static readonly ConcurrentDictionary<string, ConnectionMultiplexer> ConnectionCache = new ConcurrentDictionary<string, ConnectionMultiplexer>();
       
        /// <summary>
        /// 一个RedisClientProxy实例一个对象
        /// 通过实例guid保持
        /// </summary>
        private static  readonly  ConcurrentDictionary<string, DBConnectProxy> ConnectionCacheOpt = new ConcurrentDictionary<string, DBConnectProxy>();

        /// <summary>
        /// 一个实例对应一个连接字符串
        /// </summary>
        private static readonly ConcurrentDictionary<string, string> ConnectionObjString = new ConcurrentDictionary<string, string>();
       
        /// <summary>
        /// 单例获取
        /// 默认配置或者读取配置
        /// </summary>
        public static ConnectionMultiplexer Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (Locker)
                    {
                        if (_instance == null || !_instance.IsConnected)
                        {
                            _instance = GetManager();
                        }
                    }
                }
                return _instance;
            }
        }

        /// <summary>
        /// 获取通讯代理
        /// </summary>
        /// <param name="guid"></param>
        /// <returns></returns>
        public static DBConnectProxy GetPrxoy(string guid)
        {
            DBConnectProxy proxy = null;
            ConnectionCacheOpt.TryGetValue(guid, out proxy);
            return proxy;
        }
        /// <summary>
        /// 删除缓存
        /// </summary>
        /// <param name="guid"></param>
        public static void  Remove(string guid)
        {
            DBConnectProxy prxoy = null;
            string constring = "";
            ConnectionMultiplexer con = null;
            ConnectionCacheOpt.TryRemove(guid, out prxoy);
            if(ConnectionObjString.TryRemove(guid, out constring))
            {
                if(!string.IsNullOrEmpty(constring))
                {
                    if (!ConnectionObjString.Values.Contains(constring))
                    {
                        //已经全部移除，回收连接
                        ConnectionCache.TryRemove(constring, out con);
                        con.CloseAsync();
                        
                    }
                }
               
            }
        }

        /// <summary>
        /// 添加代理
        /// </summary>
        /// <param name="guid"></param>
        /// <param name="proxy"></param>
        public static void Add(string guid, DBConnectProxy proxy)
        {
           
         ConnectionCacheOpt[guid] = proxy;
        }

        /// <summary>
        /// 缓存获取
        /// 通过配置获取
        /// </summary>
        /// <param name="connectionString"></param>
        /// <returns></returns>
        public static ConnectionMultiplexer GetConnectionMultiplexer(string connectionString)
        {
            if(string.IsNullOrEmpty(connectionString))
            {
                return Instance;
            }
            if (!ConnectionCache.ContainsKey(connectionString))
            {
                ConnectionCache[connectionString] = GetManager(connectionString);
            }
            return ConnectionCache[connectionString];
        }

        /// <summary>
        /// 创建连接
        /// </summary>
        /// <param name="connectionString"></param>
        /// <returns></returns>
        private static ConnectionMultiplexer GetManager(string connectionString = null)
        {
            connectionString = connectionString ?? RedisConnectionString;
            ConnectionMultiplexer connect = null;
          
                ConfigurationOptions opt = null;
            if (string.IsNullOrEmpty(connectionString))
            {
                opt = ConfigurationOptions.Parse("localhost");
            }
            else
            {
                ConfigurationOptions.Parse(connectionString);
            }
            connect = GetConnectionMultiplexer(opt);
            return connect;
        }
        /// <summary>
        /// 创建连接
        /// 不保存
        /// </summary>
        /// <param name="connectionString"></param>
        /// <returns></returns>
        public static ConnectionMultiplexer GetConnectionMultiplexer(ConfigurationOptions opt)
        {
            ConnectionMultiplexer connect = null;
            if (opt == null)
            {
                connect = Instance;
            }
            else
            {
                 connect = ConnectionMultiplexer.Connect(opt);
            }

            //注册如下事件
            connect.ConnectionFailed += MuxerConnectionFailed;
            connect.ConnectionRestored += MuxerConnectionRestored;
            connect.ErrorMessage += MuxerErrorMessage;
            connect.ConfigurationChanged += MuxerConfigurationChanged;
            connect.HashSlotMoved += MuxerHashSlotMoved;
            connect.InternalError += MuxerInternalError;
            //启动一个线程
            if(checkClose==null)
            {
                lock(lock_Thread)
                {
                    if(checkClose == null)
                    {
                        checkClose = new Thread(Check);
                        checkClose.IsBackground = true;
                        checkClose.Name = "RedisClientClose";
                        checkClose.Start();

                    }
                }
              
            }
            return connect;
        }

        /// <summary>
        /// 创建连接
        /// </summary>
        /// <param name="config"></param>
        /// <returns></returns>
        public static ConnectionMultiplexer GetConnectionMultiplexer(ConfigRedis config)
        {
            ConfigurationOptions opt = Convert(config);
            if (opt == null && config.IsDefult == false)
            {
                return null;
            }
            else
            {
                return GetConnectionMultiplexer(opt);
            }

           

           
        }

        /// <summary>
        /// 添加连接关系
        /// </summary>
        /// <param name="guid"></param>
        /// <param name="con"></param>
        public static void AddGuidCon(string guid,string con)
        {
            ConnectionObjString[guid] = con;
        }

        /// <summary>
        ///配置转换
        /// </summary>
        /// <param name="config"></param>
        /// <returns></returns>
        private static ConfigurationOptions Convert(ConfigRedis config)
        {
            //
            StringBuilder sbr = new StringBuilder();
            FieldInfo[] finfos = config.GetType().GetFields(System.Reflection.BindingFlags.NonPublic);
            foreach (FieldInfo inf in finfos)
            {
                if (inf.FieldType == typeof(List<string>))
                {
                    List<string> list = (List<string>)inf.GetValue(config);
                    foreach (string str in list)
                    {
                        sbr.AppendFormat("{0},", str);
                    }
                }
                else
                {
                    sbr.AppendFormat("{0},", inf.GetValue(config));
                }
            }
            if (config.Configother != null && config.Configother.Count > 0)
            {
                foreach (KeyValuePair<string, string> kv in config.Configother)
                {
                    sbr.AppendFormat("{0}={1}", kv.Key, kv.Value);
                }
            }
            //
            if (sbr.Length > 0)
            {
                sbr.Remove(sbr.Length - 1, 1);
            }
            try
            {
                ConfigurationOptions opt = ConfigurationOptions.Parse(sbr.ToString());
                return opt;
            }
            catch
            {
                return null;
            }
        }
        /// <summary>
        /// 检查是否全部关闭代理连接
        /// 全部关闭则销毁连接
        /// </summary>
        private static void  Check()
        {
            int timeout = 0;
            if(!int.TryParse(CloseTimeOut, out timeout))
            {
                timeout = 3600;
            }
            timeout = timeout * 1000;
            while (true)
            {
                if (IsAutoClose == "1")
                    break;
                Thread.Sleep(timeout);
                string[] keys= ConnectionCacheOpt.Keys.ToArray();
                DBConnectProxy proxy = null;
                foreach(string str in keys)
                {
                    proxy=GetPrxoy(str);
                    TimeSpan tsp = DateTime.Now - proxy.curTime;
                    if (tsp.TotalSeconds>timeout)
                    {
                        //删除该连接
                        Remove(str);
                    }
                }
            }
        }
        #region 事件

        /// <summary>
        /// 配置更改时
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private static void MuxerConfigurationChanged(object sender, EndPointEventArgs e)
        {
            Console.WriteLine("Configuration changed: " + e.EndPoint);
        }

        /// <summary>
        /// 发生错误时
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private static void MuxerErrorMessage(object sender, RedisErrorEventArgs e)
        {
            Console.WriteLine("ErrorMessage: " + e.Message);
        }

        /// <summary>
        /// 重新建立连接之前的错误
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private static void MuxerConnectionRestored(object sender, ConnectionFailedEventArgs e)
        {
            Console.WriteLine("ConnectionRestored: " + e.EndPoint);
        }

        /// <summary>
        /// 连接失败 ， 如果重新连接成功你将不会收到这个通知
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private static void MuxerConnectionFailed(object sender, ConnectionFailedEventArgs e)
        {
            Console.WriteLine("重新连接：Endpoint failed: " + e.EndPoint + ", " + e.FailureType + (e.Exception == null ? "" : (", " + e.Exception.Message)));
        }

        /// <summary>
        /// 更改集群
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private static void MuxerHashSlotMoved(object sender, HashSlotMovedEventArgs e)
        {
            Console.WriteLine("HashSlotMoved:NewEndPoint" + e.NewEndPoint + ", OldEndPoint" + e.OldEndPoint);
        }

        /// <summary>
        /// redis类库错误
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private static void MuxerInternalError(object sender, InternalErrorEventArgs e)
        {
            Console.WriteLine("InternalError:Message" + e.Exception.Message);
        }

        #endregion 事件
    
}
}
