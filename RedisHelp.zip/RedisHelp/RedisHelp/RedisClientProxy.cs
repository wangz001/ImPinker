﻿using IRedisClient;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace RedisClient
{

    /// <summary>
    /// 创建连接使用代理
    /// 直接操作数据库
    /// 本类实现原理：一个实例，通过相同连接字符串共享连接
    /// 所有实例关闭则销毁ConnectionMultiplexer连接
    /// 
    /// </summary>
    internal class RedisClientProxy:IRedisClientObj
    {
        public static readonly RedisClientProxy instance = new RedisClientProxy();
        private int DbNum { get; }

      
        /// <summary>
        /// HASH存储
        /// </summary>
        public HashStore HashHelp
        {
            get
            {
                RedisClientManger.GetPrxoy(guid).curTime = DateTime.Now;
                return hashhp;
            }
        }

        /// <summary>
        /// key操作
        /// </summary>
        public KeyStore KeyHelp
        {
            get
            {
                RedisClientManger.GetPrxoy(guid).curTime = DateTime.Now;
                return keyhp;
            }
        }

        /// <summary>
        /// List存储
        /// </summary>
        public ListStore ListHelp
        {
            get
            {
                RedisClientManger.GetPrxoy(guid).curTime = DateTime.Now;
                return listhp;
            }
        }

        /// <summary>
        /// 服务操作
        /// </summary>
        public ServerStore ServerHelp
        {
            get
            {
                RedisClientManger.GetPrxoy(guid).curTime = DateTime.Now;
                return serverhp;
            }
        }

        /// <summary>
        /// SortSet存储
        /// </summary>
        public SortSetStore SortSetHelp
        {
            get
            {
                RedisClientManger.GetPrxoy(guid).curTime = DateTime.Now;
                return sorthp;
            }
        }

        /// <summary>
        /// 字符串存储
        /// </summary>
        public StringStore StringHelp
        {
            get
            {
                RedisClientManger.GetPrxoy(guid).curTime = DateTime.Now;
                return stringhp;
            }
        }
        /// <summary>
        /// 数据订阅发布
        /// </summary>
        public DataEventBus DataBusHelp
        {
            get
            {
                return dataQueuehp;
            }
        }

        private  ConnectionMultiplexer _conn;
        public string CustomKey;
        private HashHelper hashhp;
        private StringHelper stringhp;
        private ListHelper listhp;
        private SortedSetHelper sorthp;
        private KeyHelper keyhp;
        private ServerHelper serverhp;
        private DataQueueHelper dataQueuehp;
        HelpCom hp = null;
        string guid="";
        public RedisClientProxy()
        {
            guid = Guid.NewGuid().ToString();
            AddCache();
            hashhp = new HashHelper(guid);
            stringhp = new StringHelper(guid);
            listhp = new ListHelper(guid);

            sorthp = new SortedSetHelper(guid);
            keyhp = new KeyHelper(guid);
            serverhp = new ServerHelper(guid);
            dataQueuehp = new DataQueueHelper(guid);




        }
        /// <summary>
        /// 连接创建
        /// </summary>
        private void AddCache()
        {

             hp = new HelpCom(_conn, CustomKey) { DbNum = DbNum };
             DBConnectProxy prxoy = new DBConnectProxy() { hpcom = hp };

            RedisClientManger.Add(guid, prxoy);
        }

        /// <summary>
        /// 连接
        /// </summary>
        /// <param name="con">连接字符串</param>
        public void Connect(string con=null)
        {
            DBConnectProxy prxoy = null;
           _conn = RedisClientManger.GetConnectionMultiplexer(con);
            RedisClientManger.AddGuidCon(guid, con);
            prxoy=RedisClientManger.GetPrxoy(guid);
            prxoy.hpcom.SetCon(_conn);
            prxoy.hpcom.SetKey(CustomKey);
            
        }
       
        /// <summary>
        /// 连接
        /// </summary>
        /// <param name="opt">配置</param>
        public void Connect(ConfigurationOptions opt)
        {
            DBConnectProxy prxoy = null;
            _conn = RedisClientManger.GetConnectionMultiplexer(opt);
            prxoy= RedisClientManger.GetPrxoy(guid);
            prxoy.hpcom.SetCon(_conn);
            prxoy.hpcom.SetKey(CustomKey);
        }

        /// <summary>
        /// 连接
        /// </summary>
        /// <param name="config">配置</param>
        public void Connect(ConfigRedis config)
        {
            _conn= RedisClientManger.GetConnectionMultiplexer(config);
            DBConnectProxy prxoy = null;
            prxoy = RedisClientManger.GetPrxoy(guid);
            prxoy.hpcom.SetCon(_conn);
            prxoy.hpcom.SetKey(CustomKey);
           // hp.SetKey(CustomKey);
        }
      
        /// <summary>
        /// 设置前缀
        /// </summary>
        /// <param name="customKey"></param>
        public void SetSysCustomKey(string customKey)
        {
            CustomKey = customKey;
        }

        /// <summary>
        /// 关闭连接
        /// </summary>
        public void Close()
        {

            RedisClientManger.Remove(guid);
        }
    }
}
