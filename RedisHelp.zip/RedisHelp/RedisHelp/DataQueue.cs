﻿using IRedisClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StackExchange.Redis;

namespace RedisClient
{

    /// <summary>
    /// 数据发布订阅操作
    /// </summary>
    public class DataQueueHelper : DataEventBus
    {
        public int DbNum { get; set; }
       
        HelpCom hpcom = new HelpCom(null,null);
        DBConnectProxy prxoy = null;
        public DataQueueHelper(string guid)
        {

            prxoy = RedisClientManger.GetPrxoy(guid);
            hpcom = prxoy.hpcom;
        }
        /// <summary>
        /// 发布
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="channel"></param>
        /// <param name="msg"></param>
        /// <returns></returns>
        public override long Publish<T>(string channel, T msg)
        {
            ISubscriber sub = hpcom.GetConnection().GetSubscriber();
            return sub.Publish(channel,hpcom.ConvertJson<T>(msg));
        }
        /// <summary>
        /// 订阅
        /// </summary>
        /// <param name="subChannel"></param>
        /// <param name="handler"></param>
        public override void Subscribe(string subChannel, Action<RedisChannel, RedisValue> handler = null)
        {
            ISubscriber sub = hpcom.GetConnection().GetSubscriber();
            sub.Subscribe(subChannel, (channel, message) =>
            {
                if (handler == null)
                {
                    Console.WriteLine(subChannel + " 订阅收到消息：" + message);
                }
                else
                {
                    handler(channel, message);
                }
            });
        }
        /// <summary>
        /// 取消订阅
        /// </summary>
        /// <param name="channel"></param>
        public override void Unsubscribe(string channel)
        {
             ISubscriber sub = hpcom.GetConnection().GetSubscriber();
             sub.Unsubscribe(channel);
        }
        /// <summary>
        /// 取消所有订阅
        /// </summary>
        public override void UnsubscribeAll()
        {
            ISubscriber sub = hpcom.GetConnection().GetSubscriber();
            sub.UnsubscribeAll();
        }
    }
    
}
