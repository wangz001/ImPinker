﻿using IRedisClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RedisClient
{

    /// <summary>
    /// 直接创建实现实例
    /// </summary>
   public  class ObjFactory
    {
        /// <summary>
        /// 返回实例
        /// </summary>
        /// <returns></returns>
        public static IRedisClientObj Create()
        {
            return new RedisClientProxy();
        }
    }
}
