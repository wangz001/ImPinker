﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RedisClientDemo
{
   public class Person
    {
        public string ID;
        public string Name;
        public int Age;
        public List<string> list = new List<string>();
    }
}
