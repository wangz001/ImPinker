﻿using RedisClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using IRedisClient;
namespace RedisClientDemo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int i = 0;
        private void btn_Test_Click(object sender, EventArgs e)
        {
            //RedisClientProxy prxoy = new RedisClientProxy();
            //prxoy.Connect();
            //prxoy.Stringhp.StringSet("ss", "mmmm");
            //string ssss = prxoy.stringhp.StringGet("ss");
            // IRedisClientObj obj = IObjManager.CreateInstance();
            IRedisClientObj obj=ObjFactory.Create();

            if (obj != null)
            {
                obj.Connect();
                // obj.StringHelp.StringSet(Guid.NewGuid().ToString(), Guid.NewGuid().ToString());
                List<string> list = new List<string>(new string[] { "1", "1" });
                var r = obj.StringHelp.StringSetItem<Person>("jinyu", new Person() { Age = 13, ID = "34", Name = "jinyu", list=list });
                 //var ru= r.Result;
                i++;
            }
        }

        private void btn_TestS_Click(object sender, EventArgs e)
        {
            Person p = new Person() { Age = 10, ID = "errr", Name = "jin" };
            p.list.AddRange(new string[] { "dd", "ss", "gg" });
            HelpCom hp = new HelpCom(null,null);
            byte[]ss=  hp.Serializer<Person>(p);
           Person sd=  hp.DeSerializer<Person>(ss);


        }
    }
}
