﻿using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRedisClient
{
    public abstract class StringStore
    {
        public abstract bool StringSet(string key, string value, TimeSpan? expiry = default(TimeSpan?));
        public abstract bool StringSet(List<KeyValuePair<RedisKey, RedisValue>> keyValues);
        public abstract bool StringSet<T>(string key, T obj, TimeSpan? expiry = default(TimeSpan?));
        public abstract bool StringSetItem<T>(string key, T obj, TimeSpan? expiry = default(TimeSpan?));
        public abstract string StringGet(string key);
        public abstract RedisValue[] StringGet(List<string> listKey);
        public abstract T StringGet<T>(string key);
        public abstract T StringGetItem<T>(string key);
        public abstract double StringIncrement(string key, double val = 1);
        public abstract double StringDecrement(string key, double val = 1);

       public abstract  Task<bool> StringSetAsync(string key, string value, TimeSpan? expiry = default(TimeSpan?));

        public abstract Task<bool> StringSetAsync(List<KeyValuePair<RedisKey, RedisValue>> keyValues);
        public abstract Task<bool> StringSetAsync<T>(string key, T obj, TimeSpan? expiry = default(TimeSpan?));
        public abstract Task<bool> StringSetAsyncItem<T>(string key, T obj, TimeSpan? expiry = default(TimeSpan?));
        public abstract Task<string> StringGetAsync(string key);
        public abstract Task<RedisValue[]> StringGetAsync(List<string> listKey);
        public abstract Task<T> StringGetAsync<T>(string key);
        public abstract Task<T> StringGetAsyncItem<T>(string key);
        public abstract Task<double> StringIncrementAsync(string key, double val = 1);
        public abstract Task<double> StringDecrementAsync(string key, double val = 1);

        //public async Task<bool> StringSetAsync(string key, string value, TimeSpan? expiry = default(TimeSpan?));
        //public async Task<bool> StringSetAsync(List<KeyValuePair<RedisKey, RedisValue>> keyValues);
        //public async Task<bool> StringSetAsync<T>(string key, T obj, TimeSpan? expiry = default(TimeSpan?));
        //public async Task<string> StringGetAsync(string key);
        //public async Task<RedisValue[]> StringGetAsync(List<string> listKey);
        //public async Task<T> StringGetAsync<T>(string key);
        //public async Task<double> StringIncrementAsync(string key, double val = 1);
        //public async Task<double> StringDecrementAsync(string key, double val = 1);
    }
}
