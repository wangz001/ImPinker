﻿using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRedisClient
{
  public abstract  class ServerStore
    {
        public abstract ITransaction CreateTransaction();
        public abstract IDatabase GetDatabase();
        public abstract IServer GetServer(string hostAndPort);
    }
}
