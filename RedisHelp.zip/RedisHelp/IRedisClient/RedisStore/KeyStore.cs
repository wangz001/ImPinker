﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRedisClient
{
  public abstract class KeyStore
    {
        public abstract bool KeyDelete(string key);
        public abstract long KeyDelete(List<string> keys);
        public abstract bool KeyExists(string key);
        public abstract bool KeyRename(string key, string newKey);
        public abstract bool KeyExpire(string key, TimeSpan? expiry = default(TimeSpan?));
    }
}
