﻿using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRedisClient
{
 public abstract  class HashStore
    {
        /// <summary>存在
        /// 查看key是否
        /// </summary>
        /// <param name="key"></param>
        /// <param name="dataKey"></param>
        /// <returns></returns>
         public abstract  bool HashExists(string key, string dataKey);
        /// <summary>
        /// 保持数据
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <param name="dataKey"></param>
        /// <param name="t"></param>
        /// <returns></returns>
        public  abstract  bool HashSet<T>(string key, string dataKey, T t);
       /// <summary>
       /// 保持数据
       /// </summary>
       /// <typeparam name="T"></typeparam>
       /// <param name="key"></param>
       /// <param name="dataKey"></param>
       /// <param name="t"></param>
       /// <returns></returns>
        public abstract bool HashSetItem<T>(string key, string dataKey, T t);

       /// <summary>
       /// 删除数据
       /// </summary>
       /// <param name="key"></param>
       /// <param name="dataKey"></param>
       /// <returns></returns>
        public abstract bool HashDelete(string key, string dataKey);

        /// <summary>
        /// 删除多个数据
        /// </summary>
        /// <param name="key"></param>
        /// <param name="dataKeys"></param>
        /// <returns></returns>
        public abstract long HashDelete(string key, List<RedisValue> dataKeys);

        /// <summary>
        /// 获取数据
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <param name="dataKey"></param>
        /// <returns></returns>
        public abstract T HashGet<T>(string key, string dataKey);
        /// <summary>
        /// 获取数据
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <param name="dataKey"></param>
        /// <returns></returns>
        public abstract T HashGetItem<T>(string key, string dataKey);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <param name="dataKey"></param>
        /// <param name="val"></param>
        /// <returns></returns>
        public abstract double HashIncrement(string key, string dataKey, double val = 1);
        /// <summary>
        /// 
        /// </summary>
        /// <param name="key"></param>
        /// <param name="dataKey"></param>
        /// <param name="val"></param>
        /// <returns></returns>
        public abstract double HashDecrement(string key, string dataKey, double val = 1);
        public abstract  List<T> HashKeys<T>(string key);
        /// <summary>
        /// 异步检查key
        /// </summary>
        /// <param name="key"></param>
        /// <param name="dataKey"></param>
        /// <returns></returns>
        public abstract  Task<bool> HashExistsAsync(string key, string dataKey);

        /// <summary>
        /// 异步存储
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <param name="dataKey"></param>
        /// <param name="t"></param>
        /// <returns></returns>
        public abstract  Task<bool> HashSetAsync<T>(string key, string dataKey, T t);
       /// <summary>
       ///异步删除
       /// </summary>
       /// <param name="key"></param>
       /// <param name="dataKey"></param>
       /// <returns></returns>
        public abstract  Task<bool> HashDeleteAsync(string key, string dataKey);
        /// <summary>
        /// 异步获取数据
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <param name="dataKey"></param>
        /// <returns></returns>
        public abstract  Task<T> HashGeAsync<T>(string key, string dataKey);
       /// <summary>
       /// 异步获取
       /// </summary>
       /// <typeparam name="T"></typeparam>
       /// <param name="key"></param>
       /// <param name="dataKey"></param>
       /// <returns></returns>
        public abstract Task<T> HashGeAsyncItem<T>(string key, string dataKey);
        public abstract  Task<double> HashIncrementAsync(string key, string dataKey, double val = 1);
        public abstract  Task<double> HashDecrementAsync(string key, string dataKey, double val = 1);
        public abstract  Task<List<T>> HashKeysAsync<T>(string key);
        public abstract Task<List<T>> HashKeysAsyncItem<T>(string key);



        //public abstract async Task<bool> HashExistsAsync(string key, string dataKey);
        //public abstract async Task<bool> HashSetAsync<T>(string key, string dataKey, T t);
        //public abstract async Task<bool> HashDeleteAsync(string key, string dataKey);
        //public abstract async Task<T> HashGeAsync<T>(string key, string dataKey);
        //public abstract async Task<double> HashIncrementAsync(string key, string dataKey, double val = 1);
        //public abstract async Task<double> HashDecrementAsync(string key, string dataKey, double val = 1);
        //public abstract async Task<List<T>> HashKeysAsync<T>(string key);

    }
}
