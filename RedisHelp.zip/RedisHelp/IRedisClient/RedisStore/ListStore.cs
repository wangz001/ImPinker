﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRedisClient
{
  public abstract  class ListStore
    {
        public abstract void ListRemove<T>(string key, T value);
        public abstract List<T> ListRange<T>(string key);
        public abstract void ListRightPush<T>(string key, T value);
        public abstract T ListRightPop<T>(string key);
        public abstract void ListLeftPush<T>(string key, T value);
        public abstract T ListLeftPop<T>(string key);
        public abstract void ListRemoveItem<T>(string key, T value);
        public abstract List<T> ListRangeItem<T>(string key);
        public abstract void ListRightPushItem<T>(string key, T value);
        public abstract T ListRightPopItem<T>(string key);
        public abstract void ListLeftPushItem<T>(string key, T value);
        public abstract T ListLeftPopItem<T>(string key);
        public abstract long ListLength(string key);

        public abstract  Task<long> ListRemoveAsync<T>(string key, T value);
        public abstract  Task<List<T>> ListRangeAsync<T>(string key);
        public abstract Task<List<T>> ListRangeAsyncItems<T>(string key);
        public abstract  Task<long> ListRightPushAsync<T>(string key, T value);
        public abstract  Task<T> ListRightPopAsync<T>(string key);
        public abstract Task<T> ListRightPopAsyncItem<T>(string key);
        public abstract  Task<long> ListLeftPushAsync<T>(string key, T value);
        public abstract  Task<T> ListLeftPopAsync<T>(string key);
        public abstract Task<T> ListLeftPopAsyncItem<T>(string key);
        public abstract  Task<long> ListLengthAsync(string key);


        //public abstract async Task<long> ListRemoveAsync<T>(string key, T value);
        //public abstract async Task<List<T>> ListRangeAsync<T>(string key);
        //public abstract async Task<long> ListRightPushAsync<T>(string key, T value);
        //public abstract async Task<T> ListRightPopAsync<T>(string key);
        //public abstract async Task<long> ListLeftPushAsync<T>(string key, T value);
        //public abstract async Task<T> ListLeftPopAsync<T>(string key);
        //public abstract async Task<long> ListLengthAsync(string key);
    }
}
