﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRedisClient
{
   public   abstract class SortSetStore
    {
        public abstract  bool SortedSetAdd<T>(string key, T value, double score);
        public abstract bool SortedSetRemove<T>(string key, T value);
        public abstract List<T> SortedSetRangeByRank<T>(string key);

        public abstract bool SortedSetAddItem<T>(string key, T value, double score);
        public abstract bool SortedSetRemoveItem<T>(string key, T value);
        public abstract List<T> SortedSetRangeByRankItem<T>(string key);
        public abstract long SortedSetLength(string key);

        public abstract  Task<bool> SortedSetAddAsync<T>(string key, T value, double score);

        public abstract Task<bool> SortedSetAddAsyncItem<T>(string key, T value, double score);
        public abstract  Task<bool> SortedSetRemoveAsync<T>(string key, T value);
        public abstract Task<bool> SortedSetRemoveAsyncItem<T>(string key, T value);
        public abstract  Task<List<T>> SortedSetRangeByRankAsync<T>(string key);
        public abstract Task<List<T>> SortedSetRangeByRankAsyncItem<T>(string key);
        public abstract  Task<long> SortedSetLengthAsync(string key);


        //public abstract async Task<bool> SortedSetAddAsync<T>(string key, T value, double score);
        //public abstract async Task<bool> SortedSetRemoveAsync<T>(string key, T value);
        //public abstract async Task<List<T>> SortedSetRangeByRankAsync<T>(string key);
        //public abstract async Task<long> SortedSetLengthAsync(string key);
    }
}
