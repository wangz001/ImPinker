﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRedisClient
{
   public class ConfigRedis
    {
       
        List<string> host = new List<string>();
        bool abortConnect = true;
        bool allowAdmin = false;
                               
                               
        int connectTimeout = 0;
                              
                               
          string name = "";         
                                  
        int syncTimeout = 0;


        int writeBuffer = 1024;            

        private Dictionary<string, string> configother = new Dictionary<string, string>();
        /// <summary>
        /// 配置转换错误是否使用默认值
        /// </summary>
        public bool IsDefult
        {
            get; set;
        }
        /// <summary>
        /// 当为true时，当没有可用的服务器时则不会创建一个连接
        /// </summary>
        public bool AbortConnect
        {
            get
            {
                return abortConnect;
            }

            set
            {
                abortConnect = value;
            }
        }

        /// <summary>
        /// 当为true时 ，可以使用一些被认为危险的命令
        /// </summary>
        public bool AllowAdmin
        {
            get
            {
                return allowAdmin;
            }

            set
            {
                allowAdmin = value;
            }
        }
        /// <summary>
        /// 超时时间
        /// </summary>
        public int ConnectTimeout
        {
            get
            {
                return connectTimeout;
            }

            set
            {
                connectTimeout = value;
            }
        }
        /// <summary>
        /// 客户端名称
        /// </summary>
        public string Name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }
        /// <summary>
        /// 异步超时(毫秒)
        /// </summary>
        public int SyncTimeout
        {
            get
            {
                return syncTimeout;
            }

            set
            {
                syncTimeout = value;
            }
        }

        /// <summary>
        /// 缓冲区大小
        /// </summary>
        public int WriteBuffer
        {
            get
            {
                return writeBuffer;
            }

            set
            {
                writeBuffer = value;
            }
        }
        /// <summary>
        /// 其它配置项
        /// </summary>
        public Dictionary<string, string> Configother
        {
            get
            {
                return configother;
            }

            set
            {
                configother = value;
            }
        }

        /// <summary>
        /// 主机
        /// IP:Port
        /// </summary>
        public List<string> Host
        {
            get
            {
                return host;
            }

            set
            {
                host = value;
            }
        }
    }
}
