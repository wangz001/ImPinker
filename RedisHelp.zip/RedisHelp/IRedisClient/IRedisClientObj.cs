﻿
using StackExchange.Redis;

namespace IRedisClient
{
   public interface IRedisClientObj
    {
        /// <summary>
        /// Hash存储
        /// </summary>
         HashStore HashHelp { get; }
        /// <summary>
        /// Key操作
        /// </summary>
         KeyStore KeyHelp { get; }
        /// <summary>
        /// List存储
        /// </summary>
         ListStore ListHelp { get; }
        /// <summary>
        /// server操作
        /// </summary>
         ServerStore ServerHelp { get; }

        /// <summary>
        /// SortSet存储
        /// </summary>
         SortSetStore SortSetHelp { get; }

        /// <summary>
        /// String存储
        /// </summary>
         StringStore StringHelp { get; }

        /// <summary>
        /// 数据发布订阅
        /// </summary>
        DataEventBus DataBusHelp { get; }

        /// <summary>
        /// 连接
        /// </summary>
        /// <param name="con">连接字符串</param>
        void Connect(string con = null);
        /// <summary>
        /// 连接
        /// </summary>
        /// <param name="opt"></param>
        void Connect(ConfigurationOptions opt);
        /// <summary>
        /// 连接
        /// </summary>
        /// <param name="config"></param>
        void Connect(ConfigRedis config);

        /// <summary>
        /// 关闭连接
        /// </summary>
        void Close();

        /// <summary>
        /// 设置Key标记
        /// </summary>
        /// <param name="customKey"></param>
        void SetSysCustomKey(string customKey);
    }
}
