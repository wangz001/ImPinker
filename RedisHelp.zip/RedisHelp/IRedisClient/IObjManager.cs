﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace IRedisClient
{

    /// <summary>
    /// 在接口上动态加载实现类
    /// 获取实例
    /// </summary>
   public class IObjManager
    {
        public static string fileName = "RedisClient.dll";
        private static string childClass = "";
        public static string filePath = AppDomain.CurrentDomain.BaseDirectory;

        /// <summary>
        /// 创建实例
        /// </summary>
        /// <returns></returns>
        public static IRedisClientObj CreateInstance()
        {
            Assembly ass= Assembly.LoadFile(filePath+fileName);
            IRedisClientObj obj = null;
            if (string.IsNullOrEmpty(childClass))
            {
                Type[] allTypes = ass.GetTypes();
                foreach (Type child in  allTypes)
                {
                    if (child.GetInterface("IRedisClientObj") != null && child.IsClass)
                    {
                        // 这个type就是子类了，之后你想实例化还是存到list里面就是你的事了
                        obj=(IRedisClientObj) ass.CreateInstance(child.FullName);
                        
                        childClass = child.FullName;
                        return obj;
                    }
                }
            }
            else
            {
                 obj = (IRedisClientObj)ass.CreateInstance(childClass);
                return obj;
            }
            return obj;
        }
    }
}
