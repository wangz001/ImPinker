﻿using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IRedisClient
{
  public abstract   class DataEventBus
    {
        public abstract void Subscribe(string subChannel, Action<RedisChannel, RedisValue> handler = null);
        public abstract long Publish<T>(string channel, T msg);

        public abstract void Unsubscribe(string channel);
        public abstract void UnsubscribeAll();
    }
}
