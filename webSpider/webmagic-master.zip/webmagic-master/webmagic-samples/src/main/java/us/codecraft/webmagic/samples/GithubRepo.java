package us.codecraft.webmagic.samples;

/**
 * @author code4crafer@gmail.com
 */
public class GithubRepo {

    private String name;

    private String author;

    private String readme;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getReadme() {
        return readme;
    }

    public void setReadme(String readme) {
        this.readme = readme;
    }
}